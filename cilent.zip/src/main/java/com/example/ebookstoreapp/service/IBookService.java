package com.example.ebookstoreapp.service;
 
import java.util.List;
 
import com.example.ebookstoreapp.entity.Book;
 
public interface IBookService {
	public Book addBook(Book book);
	public Book updateBook(Book book);
	public List<Book> getAllBooks();
	public Book getBookById(int id);
	public void deleteBookById(int id);
	public List<Book> findByTitle(String title);
	public List<Book> findByPublisher(String publisher);
	public List<Book> findByPublicationYear(int publicationYear);
}