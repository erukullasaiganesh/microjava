package com.example.ebookstoreapp.controller;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
 
import com.example.ebookstoreapp.entity.Book;
import com.example.ebookstoreapp.service.BookService;
import com.example.ebookstoreapp.service.IBookService;
 
@RestController
@Scope(value = "request")
public class BookController {
 
    @Autowired
    @Qualifier(value = "bookService")
    private IBookService bookService;
 
    @PostMapping
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        Book savedBook = bookService.addBook(book);
        return new ResponseEntity<>(savedBook, HttpStatus.CREATED);
    }
 
    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable int id, @RequestBody Book book) {
    	book.setId(id);
        Book updatedBook = bookService.updateBook(book);
        return new ResponseEntity<>(updatedBook, HttpStatus.OK);
    }
 
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = bookService.getAllBooks();
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
 
    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable int id) {
        Book book = bookService.getBookById(id);
        return new ResponseEntity<>(book, HttpStatus.OK);
    }
 
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBookById(@PathVariable int id) {
        bookService.deleteBookById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
 
    @GetMapping("/search/title")
    public ResponseEntity<List<Book>> findByTitle(@RequestParam String title) {
        List<Book> books = bookService.findByTitle(title);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
 
    @GetMapping("/search/publisher")
    public ResponseEntity<List<Book>> findByPublisher(@RequestParam String publisher) {
        List<Book> books = bookService.findByPublisher(publisher);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
 
    @GetMapping("/search/year")
    public ResponseEntity<List<Book>> findByYear(@RequestParam int publicationYear) {
        List<Book> books = bookService.findByPublicationYear(publicationYear);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
}